package com.redcore.performance.ui.deviceinfo

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.redcore.performance.databinding.FragmentDeviceInfoBinding

/**
 * Displays real device information sourced entirely from android.os.Build
 * and PackageManager — no root or Shizuku required for any field here.
 */
class DeviceInfoFragment : Fragment() {

    private var _binding: FragmentDeviceInfoBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDeviceInfoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val info = buildString {
            appendLine("Manufacturer: ${Build.MANUFACTURER}")
            appendLine("Brand: ${Build.BRAND}")
            appendLine("Model: ${Build.MODEL}")
            appendLine("Device: ${Build.DEVICE}")
            appendLine("Product: ${Build.PRODUCT}")
            appendLine("Hardware: ${Build.HARDWARE}")
            appendLine("Board: ${Build.BOARD}")
            appendLine()
            appendLine("Android Version: ${Build.VERSION.RELEASE}")
            appendLine("SDK Version: ${Build.VERSION.SDK_INT}")
            appendLine("Security Patch: ${Build.VERSION.SECURITY_PATCH}")
            appendLine("Build Fingerprint: ${Build.FINGERPRINT}")
            appendLine()
            appendLine("CPU Architecture: ${Build.SUPPORTED_ABIS.joinToString()}")
            appendLine("CPU Cores: ${Runtime.getRuntime().availableProcessors()}")
        }
        binding.deviceInfoText.text = info
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
