package com.redcore.performance.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.redcore.performance.data.entities.BenchmarkResult
import kotlinx.coroutines.flow.Flow

@Dao
interface BenchmarkDao {
    @Insert
    suspend fun insert(result: BenchmarkResult)

    @Query("SELECT * FROM benchmark_results ORDER BY timestampMs DESC")
    fun observeAll(): Flow<List<BenchmarkResult>>

    @Query("SELECT * FROM benchmark_results ORDER BY timestampMs DESC LIMIT 1")
    suspend fun getLatest(): BenchmarkResult?
}
