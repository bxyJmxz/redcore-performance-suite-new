package com.redcore.performance.ui.appmanager

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.core.widget.addTextChangedListener
import androidx.recyclerview.widget.LinearLayoutManager
import com.redcore.performance.databinding.FragmentAppManagerBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class AppManagerFragment : Fragment() {

    private var _binding: FragmentAppManagerBinding? = null
    private val binding get() = _binding!!
    private val viewModel: AppManagerViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAppManagerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val adapter = InstalledAppsAdapter { app ->
            // "App Information" -> jump to the real Android system settings page for that app
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${app.packageName}")
            }
            startActivity(intent)
        }
        binding.appsList.layoutManager = LinearLayoutManager(requireContext())
        binding.appsList.adapter = adapter

        binding.searchInput.addTextChangedListener(onTextChanged = { text, _, _, _ ->
            viewModel.search(text?.toString().orEmpty())
        })
        binding.systemAppsToggle.setOnCheckedChangeListener { _, _ -> viewModel.toggleSystemApps() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { viewModel.apps.collect { adapter.submitList(it) } }
                launch { viewModel.isLoading.collect { binding.loadingIndicator.visibility = if (it) View.VISIBLE else View.GONE } }
            }
        }
        viewModel.loadApps()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

