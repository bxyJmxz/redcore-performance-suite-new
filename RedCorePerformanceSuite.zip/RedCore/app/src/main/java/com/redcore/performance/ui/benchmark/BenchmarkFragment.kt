package com.redcore.performance.ui.benchmark

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.redcore.performance.databinding.FragmentBenchmarkBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class BenchmarkFragment : Fragment() {

    private var _binding: FragmentBenchmarkBinding? = null
    private val binding get() = _binding!!
    private val viewModel: BenchmarkViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBenchmarkBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val historyAdapter = BenchmarkHistoryAdapter()
        binding.historyList.layoutManager = LinearLayoutManager(requireContext())
        binding.historyList.adapter = historyAdapter

        binding.runBenchmarkButton.setOnClickListener { viewModel.runBenchmark() }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.isRunning.collect { running ->
                        binding.runBenchmarkButton.isEnabled = !running
                        binding.runBenchmarkButton.text = if (running) "Running…" else "Run Benchmark"
                        binding.progressIndicator.visibility = if (running) View.VISIBLE else View.GONE
                    }
                }
                launch {
                    viewModel.latestResult.collect { result ->
                        result ?: return@collect
                        binding.latestScoreText.text = result.overallScore.toString()
                        binding.latestDetailText.text =
                            "CPU ${result.cpuScore} · RAM ${result.ramScore} · Storage ${result.storageScore}"
                    }
                }
                launch {
                    viewModel.history.collect { historyAdapter.submitList(it) }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
