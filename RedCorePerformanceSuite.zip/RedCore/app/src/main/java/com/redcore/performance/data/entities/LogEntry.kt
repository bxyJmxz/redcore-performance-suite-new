package com.redcore.performance.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "log_entries")
data class LogEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,      // e.g. "Optimization", "Benchmark", "Error", "Root", "Cleaner"
    val message: String,
    val timestampMs: Long = System.currentTimeMillis()
)
