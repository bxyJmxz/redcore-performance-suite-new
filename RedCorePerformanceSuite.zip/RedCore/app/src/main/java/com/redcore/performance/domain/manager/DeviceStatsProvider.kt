package com.redcore.performance.domain.manager

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.view.Display
import android.view.WindowManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.delay
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Reads real hardware/battery/storage/network values via official Android APIs only.
 * No simulated numbers. Anything Android doesn't expose (GPU usage, raw CPU frequency,
 * touch sampling rate) is simply not included here.
 */
@Singleton
class DeviceStatsProvider @Inject constructor(
    @ApplicationContext private val context: Context
) {

    private val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    fun snapshot(): DeviceStats {
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)

        val batteryIntent = context.registerReceiver(
            null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )
        val batteryPct = batteryIntent?.let {
            val level = it.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = it.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) ((level * 100) / scale) else -1
        } ?: -1

        val tempTenthsC = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val plugged = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val healthInt = batteryIntent?.getIntExtra(BatteryManager.EXTRA_HEALTH, -1) ?: -1

        val internalStat = StatFs(Environment.getDataDirectory().path)

        val activeNetwork = connectivityManager.activeNetwork
        val caps = activeNetwork?.let { connectivityManager.getNetworkCapabilities(it) }

        val refreshRate = try {
            val display: Display? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.display
            } else {
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay
            }
            display?.refreshRate ?: 60f
        } catch (e: Exception) {
            60f
        }

        return DeviceStats(
            ramTotalBytes = memInfo.totalMem,
            ramAvailableBytes = memInfo.availMem,
            ramUsedBytes = memInfo.totalMem - memInfo.availMem,
            isLowRamDevice = activityManager.isLowRamDevice,

            storageTotalBytes = internalStat.totalBytes,
            storageFreeBytes = internalStat.availableBytes,

            batteryPercent = batteryPct,
            batteryTemperatureCelsius = tempTenthsC / 10f,
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL,
            chargePlugType = when (plugged) {
                BatteryManager.BATTERY_PLUGGED_AC -> "AC"
                BatteryManager.BATTERY_PLUGGED_USB -> "USB"
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
                else -> "Unplugged"
            },
            batteryHealth = when (healthInt) {
                BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
                BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheating"
                BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
                BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
                BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
                else -> "Unknown"
            },

            cpuCoreCount = Runtime.getRuntime().availableProcessors(),
            cpuAbi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown",

            networkType = when {
                caps == null -> "None"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Other"
            },
            isNetworkConnected = caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ?: false,

            displayRefreshRateHz = refreshRate,

            timestampMs = System.currentTimeMillis()
        )
    }

    /**
     * Lifecycle-aware polling stream. Collect this only while the screen is visible
     * (e.g. via repeatOnLifecycle) so monitoring pauses automatically when backgrounded.
     * intervalMs should scale with device tier — callers on low-end devices should pass
     * a larger interval (e.g. 3000ms) vs flagship (e.g. 1000ms).
     */
    fun observe(intervalMs: Long = 2000L): Flow<DeviceStats> = flow {
        while (true) {
            emit(snapshot())
            delay(intervalMs)
        }
    }
}
