package com.redcore.performance.data.repository

import android.os.Build
import com.redcore.performance.data.dao.BenchmarkDao
import com.redcore.performance.data.entities.BenchmarkResult
import com.redcore.performance.domain.manager.BenchmarkRunner
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BenchmarkRepository @Inject constructor(
    private val runner: BenchmarkRunner,
    private val dao: BenchmarkDao
) {
    val history: Flow<List<BenchmarkResult>> = dao.observeAll()

    suspend fun runAndSave(): BenchmarkResult {
        val scores = runner.runFullBenchmark()
        val result = BenchmarkResult(
            cpuScore = scores.cpuScore,
            ramScore = scores.ramScore,
            storageScore = scores.storageScore,
            overallScore = scores.overallScore,
            deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}"
        )
        dao.insert(result)
        return result
    }
}
