package com.redcore.performance.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.redcore.performance.data.entities.LogEntry
import kotlinx.coroutines.flow.Flow

@Dao
interface LogDao {
    @Insert
    suspend fun insert(entry: LogEntry)

    @Query("SELECT * FROM log_entries ORDER BY timestampMs DESC")
    fun observeAll(): Flow<List<LogEntry>>

    @Query("SELECT * FROM log_entries WHERE category = :category ORDER BY timestampMs DESC")
    fun observeByCategory(category: String): Flow<List<LogEntry>>

    @Query("DELETE FROM log_entries")
    suspend fun clearAll()
}
