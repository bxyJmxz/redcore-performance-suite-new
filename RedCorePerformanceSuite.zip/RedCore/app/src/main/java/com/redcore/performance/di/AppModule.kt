package com.redcore.performance.di

import android.content.Context
import androidx.room.Room
import com.redcore.performance.data.dao.BenchmarkDao
import com.redcore.performance.data.dao.LogDao
import com.redcore.performance.data.database.RedCoreDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): RedCoreDatabase =
        Room.databaseBuilder(context, RedCoreDatabase::class.java, RedCoreDatabase.DATABASE_NAME)
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideLogDao(db: RedCoreDatabase): LogDao = db.logDao()

    @Provides
    fun provideBenchmarkDao(db: RedCoreDatabase): BenchmarkDao = db.benchmarkDao()
}
