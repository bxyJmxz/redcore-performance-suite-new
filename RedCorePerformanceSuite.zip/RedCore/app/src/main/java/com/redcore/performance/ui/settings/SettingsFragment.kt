package com.redcore.performance.ui.settings

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import com.redcore.performance.databinding.FragmentSettingsBinding

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val prefs = requireContext().getSharedPreferences("redcore_settings", Context.MODE_PRIVATE)

        binding.darkThemeSwitch.isChecked = prefs.getBoolean("force_dark", true)
        binding.darkThemeSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("force_dark", checked).apply()
            AppCompatDelegate.setDefaultNightMode(
                if (checked) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            )
        }

        binding.rootConfirmationSwitch.isChecked = prefs.getBoolean("require_root_confirmation", true)
        binding.rootConfirmationSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("require_root_confirmation", checked).apply()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
