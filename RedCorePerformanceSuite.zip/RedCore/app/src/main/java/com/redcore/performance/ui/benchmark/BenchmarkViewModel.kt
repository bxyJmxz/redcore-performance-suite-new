package com.redcore.performance.ui.benchmark

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.redcore.performance.data.entities.BenchmarkResult
import com.redcore.performance.data.repository.BenchmarkRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class BenchmarkViewModel @Inject constructor(
    private val repository: BenchmarkRepository
) : ViewModel() {

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _latestResult = MutableStateFlow<BenchmarkResult?>(null)
    val latestResult: StateFlow<BenchmarkResult?> = _latestResult.asStateFlow()

    val history: StateFlow<List<BenchmarkResult>> = repository.history
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), emptyList())

    fun runBenchmark() {
        if (_isRunning.value) return
        viewModelScope.launch {
            _isRunning.value = true
            val result = repository.runAndSave()
            _latestResult.value = result
            _isRunning.value = false
        }
    }
}
