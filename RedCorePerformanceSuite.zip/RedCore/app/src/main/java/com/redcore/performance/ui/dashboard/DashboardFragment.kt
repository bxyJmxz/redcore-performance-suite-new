package com.redcore.performance.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.redcore.performance.R
import com.redcore.performance.databinding.FragmentDashboardBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.text.DecimalFormat

@AndroidEntryPoint
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val viewModel: DashboardViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.rootStatusValue.text = if (viewModel.isRooted) "Rooted" else "Not Rooted"
        binding.swipeRefresh.setOnRefreshListener {
            // stats already refresh on their own interval; this just gives immediate tactile feedback
            binding.swipeRefresh.isRefreshing = false
        }
        binding.quickBenchmarkButton.setOnClickListener {
            findNavController().navigate(R.id.benchmarkFragment)
        }
        binding.quickLogsButton.setOnClickListener {
            findNavController().navigate(R.id.logsFragment)
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.startMonitoring()
                viewModel.stats.collect { stats ->
                    stats ?: return@collect
                    val gb = 1024.0 * 1024.0 * 1024.0
                    val df = DecimalFormat("#.#")

                    binding.ramValue.text = "${stats.ramUsedPercent}%"
                    binding.ramDetail.text =
                        "${df.format((stats.ramUsedBytes / gb))} GB / ${df.format((stats.ramTotalBytes / gb))} GB"

                    binding.storageValue.text = "${stats.storageUsedPercent}%"
                    binding.storageDetail.text =
                        "${df.format(((stats.storageTotalBytes - stats.storageFreeBytes) / gb))} GB used"

                    binding.batteryValue.text = "${stats.batteryPercent}%"
                    binding.batteryDetail.text =
                        "${stats.batteryTemperatureCelsius}°C · ${stats.chargePlugType} · ${stats.batteryHealth}"

                    binding.networkValue.text = stats.networkType
                    binding.networkDetail.text = if (stats.isNetworkConnected) "Connected" else "Disconnected"

                    binding.performanceScoreValue.text = viewModel.performanceScore(stats).toString()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        viewModel.stopMonitoring()
        _binding = null
    }
}
