package com.redcore.performance.ui.appmanager

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.redcore.performance.databinding.ItemInstalledAppBinding

class InstalledAppsAdapter(
    private val onClick: (InstalledAppInfo) -> Unit
) : ListAdapter<InstalledAppInfo, InstalledAppsAdapter.ViewHolder>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemInstalledAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position), onClick)
    }

    class ViewHolder(private val binding: ItemInstalledAppBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(app: InstalledAppInfo, onClick: (InstalledAppInfo) -> Unit) {
            binding.appIcon.setImageDrawable(app.icon)
            binding.appName.text = app.appName
            binding.packageName.text = app.packageName
            binding.versionText.text = app.versionName?.let { "v$it" } ?: ""
            binding.root.setOnClickListener { onClick(app) }
        }
    }

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<InstalledAppInfo>() {
            override fun areItemsTheSame(old: InstalledAppInfo, new: InstalledAppInfo) =
                old.packageName == new.packageName
            override fun areContentsTheSame(old: InstalledAppInfo, new: InstalledAppInfo) =
                old == new
        }
    }
}
