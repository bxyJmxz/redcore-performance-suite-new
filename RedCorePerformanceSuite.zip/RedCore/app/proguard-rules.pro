# Add project specific ProGuard rules here.
-keep class com.redcore.performance.data.entities.** { *; }
-keepattributes *Annotation*
-keepclassmembers class * {
    @dagger.hilt.android.AndroidEntryPoint <init>();
}
